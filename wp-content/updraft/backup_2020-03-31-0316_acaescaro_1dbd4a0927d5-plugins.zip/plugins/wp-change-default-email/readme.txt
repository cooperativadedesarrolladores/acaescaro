=== WP Change Default Email ===
Contributors: sharmavijay79
Tags: wp mail, mail, email, change default email
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JKWDG57E8SCMA
Requires at least: 3.3
Tested up to: 3.8.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows WordPress Admins to update the default WordPress From Email Address and
Name. 

== Description ==
= WP Change Default Email =
By default WordPress uses *wordpress@your-domain.com* as the email address
and *WordPress* as From name. This plugin allows WordPress Admins to update
the default WordPress From Email Address and Name.

**WP Change Default Email, at a glance..**

- Simple. Really it is super simple.
- Enter Desired From Name and Email in WordPress Admin.
- You are done. Really all emails going out from your Wordpress site will have the email and from name as you desired.

**More information**

- Other [WordPress plugins](http://www.techeach.com/wordpress-plugins/?utm_source=wp-plugin-repo&utm_medium=link&utm_campaign=more-info-link) by [Vijay Sharma](http://www.techeach.com?utm_source=wp-plugin-repo&utm_medium=link&utm_campaign=more-info-link)
- Contact Vijay on Twitter: [@sharmavijay79](http://twitter.com/sharmavijay79)


== Installation ==
1. Upload WP Change Default Email plugin to your blog.
2. Activate it.
3. Enter the desired name and email address.

__Voila 1, 2, 3: You are done!__

== Screenshots ==
1. Go to Plugins Settings Screen and enter your Email Address and Name

== Changelog ==
= 0.3 =
* Fix Bug for duplicate plugin installations.

= 0.2 =
* Add support for languages.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
* Add Support for Languages.

= 0.1 =
* Initial release.